﻿namespace CustomerMaintenance.Models.DataLayer
{
    public class State
    {
        public string StateCode { get; set; }
        public string StateName { get; set; }
    }
}
